#/bin/sh
# quickest way to setup a www server with python:
python -m SimpleHTTPServer 8000

